Create Database Ola;
Use Ola;

#1. Retrieve all successful bookings:
Create View Successful_Bookings As
select * From bookings
Where Booking_Status = "Success";

Select * From Successful_Bookings;


#2. Find the average ride distance for each vehicle type:
Create View Ride_Distance_For_each_vehicle AS
Select Vehicle_Type, avg(Ride_Distance)
as Avrage_Distance From bookings
group by Vehicle_type;

Select * From Ride_Distance_For_each_vehicle;


#3. Get the total number of cancelled rides by customers:
select Booking_ID, Customer_ID, Booking_Status From Bookings
where Booking_Status = "Canceled by Customer";

Create view  Canceld_by_Customer AS
select COUNT(*) From bookings
Where Booking_Status = "Canceled by Customer";

select * From Canceld_by_Customer;


#4. List the top 5 customers who booked the highest number of rides:
Create view Top_5_Customers AS 
select Customer_ID, count(Booking_ID) as total_rides
from bookings
Group By Customer_ID
order by total_rides desc limit 5;

select * from Top_5_Customers;
#5. Get the number of rides cancelled by drivers due to personal and car-related issues:
create view Cancelled_by_Drivers_P_C_Issues As
select Count(*) from bookings
where Canceled_Rides_by_Driver = "Personal & Car Related issue";

select * from Cancelled_by_Drivers_P_C_Issues;


#6. Find the maximum and minimum driver ratings for Prime Sedan bookings:
Create view Max_Min_Rating_PS AS
select max(Driver_Ratings) as Max_Rating, min(Driver_Ratings) as Min_Rating from bookings
where Vehicle_Type = "Prime Sedan";

select * from Max_Min_Rating_PS;


#7. Retrieve all rides where payment was made using UPI:
create view All_Ride_PayMethod_UPI As
select * from bookings 
where Payment_Method = "UPI";

select * from All_Ride_PayMethod_UPI;

#8. Find the average customer rating per vehicle type:
Create view Avg_Customer_Rating As
select Vehicle_Type, avg(Customer_Rating) as Avg_C_Rating
from bookings
group by Vehicle_Type;

select * from Avg_Customer_Rating;


#9. Calculate the total booking value of rides completed successfully:
Create View Total_Successful_Booking_Value As
select Sum(Booking_Value) as Total_Successful_Booking_Value
from bookings
where Booking_Status = "Success";

select * from Total_Successful_Booking_Value;

#10. List all incomplete rides along with the reason:
Create view Incomplete_Ride_with_Reason As
select Booking_ID, Incomplete_Rides_Reason 
from bookings
where Incomplete_Rides = "Yes";

select * from Incomplete_Ride_with_Reason;   
